//
//  AnaimalTVC.swift
//  ZooApp
//
//  Created by Mac on 7/3/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit

class AnaimalTVC: UITableViewCell {
   
        @IBOutlet weak var animalImg: UIImageView!
        @IBOutlet weak var animalName: UILabel!
        @IBOutlet weak var animalDes: UITextView!
        
    
        
        func setanimal(animal:Animal){
            
            self.animalName.text = animal.name!
            self.animalDes.text = animal.des!
            self.animalImg.image  = UIImage(named: animal.image!)
            
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
}
