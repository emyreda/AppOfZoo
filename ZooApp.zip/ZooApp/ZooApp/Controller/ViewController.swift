//
//  ViewController.swift
//  ZooApp
//
//  Created by Mac on 7/3/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource
    
{
    
    
    var listofanimalkiller = [Animal]()
    var listofanimalnotkiller = [Animal]()
    var listofanimaltype = ["Killer","Not killer"]
    
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Data of animals
        
        listofanimalkiller.append(Animal(name: "lion", image: "lion", des:"lion live in jungle"))
        
        listofanimalkiller.append(Animal(name: "snake", image: "snake", des:"snake is toxic and dangerous  "))
        
        listofanimalkiller.append(Animal(name: "crocodeil", image: "crocodeil", des:"crocodeil live in water and air"))
        
        listofanimalkiller.append(Animal(name: "wovels", image: "wovels", des:"wovels eat humans "))
        
        listofanimalkiller.append(Animal(name: "tiger", image: "tiger", des:"tiger as strong as lion approx "))
        
        listofanimalkiller.append(Animal(name: "viper", image: "afaa", des:"viper is scary animal  "))
        
        
        listofanimalkiller.append(Animal(name: "shark", image: "hoot", des:"shark teeth is sharp  "))
        
        
        // Not killer
        
        listofanimalnotkiller.append(Animal(name: "panda", image: "panda", des:"panda is nice animal  "))
        
        listofanimalnotkiller.append(Animal(name: "rabiet", image: "rabiet", des:"rabiet is eating crrots "))
        
        listofanimalnotkiller.append(Animal(name: "elephant", image: "elephant", des:"elephant is big animal  "))
        
        listofanimalnotkiller.append(Animal(name: "cats", image: "cats", des:"cats is very nice ❣️  "))
        
        tableView?.reloadData()
       
    }
    
    
    
    ////////// method for table view //////////
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return listofanimaltype[section]
    }
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section==0{
            return listofanimalkiller.count
        }
        else{
            return listofanimalnotkiller.count
        }
        
    }
    
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellAnimal" , for:indexPath) as! AnaimalTVC
        
        
        if indexPath.section==0{
            
            cell.setanimal(animal:listofanimalkiller[indexPath.row])
        }
        else{
            
            cell.setanimal(animal:listofanimalnotkiller[indexPath.row])
        }
        
        
        cell.selectionStyle  = .none
        return cell
        
    }
    
    ////////end method of table view ///////////
    
    
    
    


}
