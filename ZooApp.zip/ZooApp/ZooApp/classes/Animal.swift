//
//  Animal.swift
//  ZooApp
//
//  Created by Mac on 7/3/19.
//  Copyright © 2019 Mac. All rights reserved.
//

import Foundation
import UIKit

class Animal {
    
    var name:String?
    var des:String?
    var image:String?
    
    
    
    init(name:String , image:String , des:String) {
        self.name = name
        self.des = des
        self.image = image
    }
    
    
    
    
}
